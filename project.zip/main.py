import machine
import time

# Pin Definitions
motor_pwm_pin = machine.Pin(5, machine.Pin.OUT)
motor_dir1_pin = machine.Pin(18, machine.Pin.OUT)
motor_dir2_pin = machine.Pin(19, machine.Pin.OUT)
encoder_a_pin = machine.Pin(2, machine.Pin.IN, machine.Pin.PULL_UP)
encoder_b_pin = machine.Pin(3, machine.Pin.IN, machine.Pin.PULL_UP)

# Global Variables
encoder_count = 0
target_speed = 0

# Proportional control parameters
Kp = 1.0  # Proportional gain

# Interrupt Handler for Encoder
def handle_encoder(pin):
    global encoder_count
    a = encoder_a_pin.value()
    b = encoder_b_pin.value()
    if a == b:
        encoder_count += 1
    else:
        encoder_count -= 1

# Setup Interrupt for Encoder
encoder_a_pin.irq(trigger=machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING, handler=handle_encoder)
encoder_b_pin.irq(trigger=machine.Pin.IRQ_RISING | machine.Pin.IRQ_FALLING, handler=handle_encoder)

# Function to set motor direction
def set_motor_direction(forward):
    motor_dir1_pin.value(forward)
    motor_dir2_pin.value(not forward)

# Function to adjust motor speed using proportional control
def adjust_motor_speed():
    global target_speed, encoder_count

    # Calculate the error (difference between target speed and current speed)
    error = target_speed - encoder_count

    # Apply proportional control
    proportional_output = Kp * error

    # Update motor speed based on proportional control output
    updated_speed = target_speed + proportional_output
    updated_speed = max(0, min(updated_speed, 255))  # Ensure speed is within valid range (0-255)

    # Update motor PWM duty cycle
    motor_pwm_pin.duty(updated_speed)

# Serial Communication Function
def serial_communication(uart):
    global target_speed
    while True:
        if uart.any():
            command = uart.read(1).decode()
            if command == 'F':
                target_speed = int(uart.readuntil(b'\n').decode())
                set_motor_direction(True)  # Forward
            elif command == 'B':
                target_speed = int(uart.readuntil(b'\n').decode())
                set_motor_direction(False)  # Backward
            elif command == 'S':
                target_speed = 0

# Set up UART for Serial Communication
uart = machine.UART(0, baudrate=115200)
uart.init(115200, bits=8, parity=None, stop=1)

# Main Loop
while True:
    # Motor Speed Adjustment
    adjust_motor_speed()

    # Serial Communication
    serial_communication(uart)

    # Add a delay or use a non-blocking approach depending on your requirements
    time.sleep_ms(10)

